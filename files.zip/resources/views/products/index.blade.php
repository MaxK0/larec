@extends('layouts.app')

@section('title', 'Каталог продуктов')

@section('content')
    <div class="top-section">
        <h1>Каталог продуктов</h1>
        <p>Выберите категорию и наслаждайтесь свежими продуктами!</p>
    </div>

    <div class="container">
        @foreach($categories as $category)
            <div class="catalog-section">
                <h2>{{ $category->name }}</h2>
                <div class="row">
                    @foreach($category->products as $product)
                        <div class="col-md-4 mb-4">
                            <div class="product-card">
                                <img src="{{ $product->image }}"
                                     alt="{{ $product->name }}"
                                     class="img-fluid">
                                <h3>{{ $product->name }}</h3>
                                <p>{{ $product->description }}</p>
                                <p class="price">{{ number_format($product->price, 0) }} руб/кг</p>
                                <form action="{{ route('cart.add', $product->id) }}" method="POST">
                                    @csrf
                                    <button type="submit" class="add-to-cart">
                                        Добавить в корзину
                                    </button>
                                </form>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        @endforeach
    </div>
@endsection
