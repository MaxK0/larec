@extends('layouts.app')

@section('title', 'Корзина')

@section('content')
    <div class="main-container">
        <div class="cart-content">
            <h1>Корзина</h1>

            @if(count($cart) > 0)
                <ul class="cart-list">
                    @foreach($cart as $item)
                        <li>
                            <div class="cart-item">
                                <img src="{{ $item['image'] }}" alt="{{ $item['name'] }}" width="50">
                                <span>{{ $item['name'] }} - {{ $item['price'] }}P x {{ $item['quantity'] }}</span>
                                <form action="{{ route('cart.remove', $item['id']) }}" method="POST">
                                    @csrf
                                    <button type="submit">Удалить</button>
                                </form>
                            </div>
                        </li>
                    @endforeach
                </ul>

                <div class="cart-total">
                    <p>Итого: <span id="total-price">{{ number_format($total, 2) }}</span>P</p>

                    <form action="{{ route('orders.checkout') }}" method="POST">
                        @csrf
                        <div class="form-group">
                            <label for="address">Адрес доставки:</label>
                            <input type="text" name="address" id="address" required class="form-control">
                        </div>
                        <button type="submit" class="btn btn-primary">Оформить заказ</button>
                    </form>
                </div>
            @else
                <p>Ваша корзина пуста</p>
            @endif
        </div>
    </div>
@endsection
