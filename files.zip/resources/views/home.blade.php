@extends('layouts.app')

@section('title', 'Главная - Интернет-магазин Ларец')

@section('content')
    <!-- Главный слайдер -->
    <section class="main-slider">
        <div id="mainCarousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="0" class="active"></button>
                <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="1"></button>
                <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="2"></button>
                <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="3"></button>
            </div>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="{{ asset('img/slider1.jpg') }}" class="d-block w-100" alt="Акции">
                    <div class="carousel-caption d-none d-md-block animate__animated animate__fadeIn">
                        <h5>Сезонные скидки до 50%</h5>
                        <p>Только этой неделе на все фрукты и овощи</p>
                        <a href="{{ route('categories.index') }}" class="btn btn-primary btn-lg">Посмотреть</a>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="{{ asset('img/slider2.jpg') }}" class="d-block w-100" alt="Новинки">
                    <div class="carousel-caption d-none d-md-block animate__animated animate__fadeIn">
                        <h5>Новые поступления</h5>
                        <p>Свежие продукты от местных фермеров</p>
                        <a href="{{ route('categories.index') }}" class="btn btn-primary btn-lg">В каталог</a>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="{{ asset('img/slider3.jpg') }}" class="d-block w-100" alt="Доставка">
                    <div class="carousel-caption d-none d-md-block animate__animated animate__fadeIn">
                        <h5>Бесплатная доставка</h5>
                        <p>При заказе от 2000 рублей</p>
                        <a href="{{ route('categories.index') }}" class="btn btn-primary btn-lg">Заказать</a>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="{{ asset('img/slider4.jpg') }}" class="d-block w-100" alt="Качество">
                    <div class="carousel-caption d-none d-md-block animate__animated animate__fadeIn">
                        <h5>Гарантия качества</h5>
                        <p>Только свежие и натуральные продукты</p>
                        <a href="{{ route('categories.index') }}" class="btn btn-primary btn-lg">В каталог</a>
                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#mainCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#mainCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon"></span>
            </button>
        </div>
    </section>

    <!-- Категории товаров -->
    <section class="categories py-5 bg-light">
        <div class="container">
            <h2 class="section-title text-center mb-5">Категории товаров</h2>
            <div class="row g-4">
                @foreach($categories as $category)
                    <div class="col-6 col-md-3">
                        <a href="{{ route('products.byCategory', $category->id) }}" class="category-card animate__animated animate__fadeInUp">
                            <div class="category-icon">
                                @if($category->image)
                                    <img src="{{ asset('storage/' . $category->image) }}" alt="{{ $category->name }}" class="img-fluid">
                                @else
                                    <i class="fas fa-box"></i>
                                @endif
                            </div>
                            <h3>{{ $category->name }}</h3>
                        </a>
                    </div>
                @endforeach
            </div>
            <div class="text-center mt-4">
                <a href="{{ route('categories.index') }}" class="btn btn-primary">Все категории</a>
            </div>
        </div>
    </section>
@endsection
