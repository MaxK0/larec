@extends('layouts.app')

@section('title', 'Вход')

@section('content')
    <div class="page-wrapper">
        <div class="login-form">
            <h1>Вход</h1>
            <form class="input_form" id="loginForm" action="{{ route('login.store') }}" method="POST">
                @csrf
                <input class="input-main" type="email" id="email" name="email" placeholder="Email" required>
                <input type="password" class="input-main" id="password" name="password" placeholder="Пароль" required>
                <button class="input_button" type="submit">Войти</button>
            </form>
            <p>Нет аккаунта? <a href="{{ route('register') }}">Зарегистрироваться</a></p>
        </div>
    </div>
@endsection
