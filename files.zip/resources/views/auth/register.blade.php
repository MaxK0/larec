@extends('layouts.app')

@section('title', 'Регистрация')

@section('content')
    <div class="page-wrapper">
        <div class="register-form">
            <h1>Зарегистрироваться</h1>
            <form class="input_form" id="registerForm" action="{{ route('register.store') }}" method="POST">
                @csrf
                <input class="input-main" type="text" id="name" name="name" placeholder="Имя" required>
                <input class="input-main" type="email" id="email" name="email" placeholder="Email" required>
                <input class="input-main" type="password" id="password" name="password" placeholder="Пароль" required>
                <input class="input-main" type="password" id="password_confirmation" name="password_confirmation" placeholder="Подтвердите пароль" required>
                <button type="submit">Зарегистрировать</button>
            </form>
            <p>Есть аккаунт? <a href="{{ route('login') }}">Войти</a></p>
        </div>
    </div>
@endsection
